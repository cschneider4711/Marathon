java -cp ../lib/hsqldb.jar org.hsqldb.server.Server --database.0 file:marathon --dbname.0 marathon
